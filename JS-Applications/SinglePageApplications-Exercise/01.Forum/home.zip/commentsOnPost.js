import { getTopicById } from './dbRequests.js'

export async function loadPageWithComments(e) {
    document.getElementById('topicList').style.display = 'none';
    document.getElementById('topicInputSection').style.display = 'none';
    document.getElementById('postWithCommets').style.display = 'block';
    
    let postData = await getTopicById(e.target.parentElement.id);

    let divForTopic = document.createElement('div');
    divForTopic.setAttribute('class', 'header');
    divForTopic.innerHTML = `<img src="./static/profile.png" alt="avatar">
    <p><span>${postData.username}</span> posted on <time>2020-10-10 12:08:28</time></p>

    <p class="post-content">${postData.postText}</p>`;

    document.getElementById('currentPostInfo').appendChild(divForTopic);
}