﻿using System;

namespace AuthorProblem
{
    [AuthorAttribute("Victor")]
    public class StartUp
    {
        [AuthorAttribute("George")]
        static void Main(string[] args)
        {

        }
    }
}
