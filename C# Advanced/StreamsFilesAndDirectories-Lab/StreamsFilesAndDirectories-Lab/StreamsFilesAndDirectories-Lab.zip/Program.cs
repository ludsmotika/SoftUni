﻿using System;
using System.IO;

namespace StreamsFilesAndDirectories_Lab
{
    public class OddLines
    {
        static void Main()
        {
            string inputFilePath = @"D:\Dani\SoftUni\StreamsFilesAndDirectories-Lab\StreamsFilesAndDirectories-Lab\input.txt";
            string outputFilePath = @"D:\Dani\SoftUni\StreamsFilesAndDirectories-Lab\StreamsFilesAndDirectories-Lab\output.txt";

            ExtractOddLines(inputFilePath, outputFilePath);
            using (StreamReader input = new StreamReader(outputFilePath))
            {
                while (true)
                {
                    Console.WriteLine(input.ReadLine());
                }
            }
        }

        public static void ExtractOddLines(string inputFilePath, string outputFilePath)
        {
         
            using (StreamReader input = new StreamReader(inputFilePath))
            {
                int counter = 0;
                string currentLine= input.ReadLine();
                using (StreamWriter output= new StreamWriter(outputFilePath))
                {
                    while (currentLine!=null)
                    {
                        if (counter%2==1)
                        {
                            output.WriteLine(currentLine);
                        }
                       counter++;
                        currentLine = input.ReadLine();
                    }
                }
            }
        }
    }

}
