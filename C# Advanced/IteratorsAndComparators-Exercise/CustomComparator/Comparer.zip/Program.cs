﻿using System;
using System.Linq;

namespace CustomComparator
{
    public class Program
    {
        static void Main(string[] args)
        {
            int[] collection = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
            Array.Sort(collection, new Comparer());
            Console.WriteLine(String.Join(" ",collection));
        }
    }
}
