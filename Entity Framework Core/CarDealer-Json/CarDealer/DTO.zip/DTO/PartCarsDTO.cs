﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO
{
    public class PartCarsDTO
    {
        public int  PartId{ get; set; }
        public int  CarId{ get; set; }
    }
}
