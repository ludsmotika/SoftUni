﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=DESKTOP-FVGCI9R\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
