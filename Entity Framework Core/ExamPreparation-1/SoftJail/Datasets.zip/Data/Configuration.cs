﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-FVGCI9R\SQLEXPRESS;Database=SoftJail;Trusted_Connection=True";
    }
}
